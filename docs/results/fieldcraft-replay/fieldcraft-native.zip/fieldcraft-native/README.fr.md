# FieldCraft natif — cinq variantes d’équerre

Ce dossier rassemble cinq variantes du même support en L, leurs recettes, modèles, STEP AP214 et audits. Il comprend aussi le job mécanique FieldCraft `bracket-hex` exécuté sur le modèle PA5. Le dossier `replay/` fournit les cinq scripts SolidCraft sources, leurs SHA-256, le convertisseur déterministe et le résumé; `source-patch/` contient le changement minimal de guard commun et son test.

## Géométrie et audits

Le profil est le L `[0,0]-[60,0]-[60,8]-[8,8]-[8,50]-[0,50]`, extrudé sur 40 mm, avec congé intérieur R6. Les noms de cas préservent l’identifiant campagne; les rayons d’axe sont ceux inscrits dans les recettes :

| Cas | Rayon trou axe X (mm) | Rayon trou axe Y (mm) | Volume exact |
|---|---:|---:|---|
| `x40-y80` | 5.000 | 2.500 | 34080 − 610π mm³ |
| `x50-y74` | 4.625 | 3.125 | 34080 − 2437π/4 mm³ |
| `x51-y74` | 4.625 | 3.1875 | 34080 − 19597π/32 mm³ |
| `x64-y64` | 4.000 | 4.000 | 34080 − 616π mm³ |
| `x80-y40` | 2.500 | 5.000 | 34080 − 610π mm³ |

Chaque modèle affine certifié a 48 blocs, 74 interfaces partagées, 140 faces externes et deux perçages traversants. L’audit porte une borne de déterminant strictement positive; la borne Hausdorff annoncée pour l’image rationnelle est 0 mm. Les détails sont dans `variants/<cas>/<cas>.audit.json` et le récapitulatif dans `reports/geometry-audit/summary.json`.

La vérification OCC/FreeCAD compare séparément les cinq STEP exportés à leurs STEP SolidCraft de référence, avec volumes par quadrature adaptative, classifications intérieures et sondes radiales. Les cinq rapports `qualification_pass` sont sous `reports/step-oracle/`. Ces résultats caractérisent les artefacts audités; ils ne prouvent pas une identité paramétrique générale au-delà des mesures consignées.

## Rejouer la construction

Extraire l’archive dans un clone compatible, puis copier le contenu de `build/fieldcraft-native/replay/` vers `build/fieldcraft-replay/`. Appliquer `source-patch/orthogonal-sketch-shared-guard.patch` si la révision cible ne contient pas déjà ce changement. Le patch ne touche que `src/orthogonal_sketch.rs` et `tests/solidcraft_sketch_features.rs`; sa base isolée est `88e5f34ad13210db01256a5fe54f85001d2edc3d`.

Depuis la racine du dépôt :

```sh
cargo build --release --bin solidcraft-trivariate
python3 build/fieldcraft-replay/replay.py --root . --cli target/release/solidcraft-trivariate
```

Le script confirme le SHA-256 des cinq intentions SolidCraft, les convertit sur la grille exacte 1/16 mm, puis construit, audite et exporte les cinq modèles. Il écrit sous `build/fieldcraft-replay/`. `source_manifest.json` contient le SHA-256 et l’origine des scripts; les journaux Make/Clippy du clone de génération sont dans `reports/geometry-audit/`.

## Job mécanique

`mechanical/fieldcraft_bracket_hex_pa5.job.json` est l’adaptation du job FieldCraft original, dont la révision et les chemins sont référencés dans `mechanical/fieldcraft-original-source.md`. Les noms historiques `F2:side:l1` et `F2:side:l5` correspondent à y=0 et y=50 : le pied est fixé, le dessus du montant reçoit +x à 6.25 MPa sur 320 mm², donc 2 kN. Le modèle exact est `mechanical/bracket-sketch.model.json`, partition PA5 de 48 blocs; son STEP a été exporté directement depuis ce modèle. Le résultat et son compte rendu sont à côté.

Le solveur natif utilise un espace Q2 continu (705 DDL scalaires); réaction −2 kN et équilibre ont été vérifiés, puis comparés à un assemblage/résolution SciPy indépendant. Ce job ne reproduit pas le maillage tet10, le solveur ni le pic de contrainte au congé de FieldCraft. La recette source exprime une force totale; le job natif la représente par une traction uniforme équivalente en résultante et moment.

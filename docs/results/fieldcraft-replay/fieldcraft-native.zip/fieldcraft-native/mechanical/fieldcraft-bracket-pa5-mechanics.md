# FieldCraft `bracket-hex` job on the PA5 model

## Source and face selection

The source job is FieldCraft's `filleted-bracket-fillet-stress`, revision `35e834652d8548384c2da8ef1b28d588c9af2ffd`; upstream paths are recorded in `fieldcraft-original-source.md`. It fixes `F2:side:l1` and applies a 2,000 N force in +x to `F2:side:l5`. The SolidCraft profile, ordered `(0,0) -> (60,0) -> (60,8) -> (8,8) -> (8,50) -> (0,50)` and extruded 40 mm along +z, identifies these as y=0 (horizontal foot) and y=50 (top end of the upright). Mechanical selection uses those planes and `outer/outline` provenance.

The native API accepts surface traction rather than a total force. The equivalent distributed load is 6.25 MPa in +x on y=50. The area is 8×40=320 mm², giving 2,000 N. Steel: E=210000 MPa, nu=0.3; q8 integration. All displacement components are fixed at y=0. Input: `fieldcraft_bracket_hex_pa5.job.json`; solved model: `bracket-sketch.model.json`. Its STEP was exported from that same model (it is not `probe.step`).

## Result

Run from the clone:

```sh
cargo run --quiet -- solve-job build/fieldcraft-replay/bracket-sketch.json build/fieldcraft-native/mechanical/fieldcraft_bracket_hex_pa5.job.json build/fieldcraft-native/mechanical/bracket-sketch.result.json
```

The model has 48 blocks; Q2 has 705 scalar degrees of freedom (2,115 interleaved vector coefficients); constraints leave 1,749 unknowns. The constraint system has rigid-mode rank 6. The solver converges in 298 iterations with relative residual `9.79e-11`. Four loaded faces total `320.00000000000034 mm²`; resultant `[2000,0,0] N`, and moment about the origin `[0,40000,-100000] N·mm`. The computed support reaction is `[-2000.00000002177,-2.98e-9,9.92e-11] N`; relative force and moment imbalances are `1.10e-11` and `5.81e-12`. Strain energy is `144.1284781 N·mm`; relative work-energy error is `3.25e-14`.

An independent SciPy solve reassembles the serialized Q2 blocks and integrates the traction. The largest right-hand-side discrepancy is `1.42e-13 N`; relative displacement-coefficient difference is `5.32e-13`. This qualifies transfer of the job and equilibrium on PA5. It does not reproduce FieldCraft's tet10 mesh or fillet stress peak.

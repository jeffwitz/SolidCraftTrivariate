#!/usr/bin/env python3
"""Replay archived SC1 design intents through the native orthogonal sketch CLI."""
from fractions import Fraction
from pathlib import Path
import argparse, hashlib, json, subprocess

CASES = ("x40-y80", "x50-y74", "x51-y74", "x64-y64", "x80-y40")
SCALE = 16

def literal(x):
    return Fraction(str(x))

def recipe_from_script(script):
    commands = script["commands"]
    if len(commands) != 7 or [c["command"] for c in commands] != [
        "sketch.create", "sketch.line", "sketch.finish", "solid.extrude",
        "solid.fillet", "solid.hole", "solid.hole"]:
        raise ValueError("unexpected SC1 feature sequence")
    sketch = commands[0]["params"]
    outline = commands[1]["params"]
    finish = commands[2]["params"]
    extrusion = commands[3]["params"]
    fillet = commands[4]["params"]
    if sketch.get("plane") != "XY" or outline.get("closed") is not True or finish:
        raise ValueError("unsupported or incomplete source sketch")
    points = outline["points"]
    vertices = [[int(literal(v) * SCALE) for v in p] for p in points]
    height = int(literal(extrusion["distance"]) * SCALE)
    edge = fillet["edges"]
    if len(edge) != 1 or [literal(v) for v in edge[0]] != [8, 8, 20]:
        raise ValueError("unexpected fillet support")
    fillet_radius = literal(fillet["radius"])
    if fillet_radius.denominator != 1:
        raise ValueError("fillet is off integer source lattice")
    bores=[]
    for hole in commands[5:]:
        p=hole["params"]
        position=[literal(v) for v in p["position"]]
        if position[0] == 8 and position[1] != 8:
            axis, component, face = "x", 0, 8
        elif position[1] == 8 and position[0] != 8:
            axis, component, face = "y", 1, 8
        else:
            raise ValueError("unsupported hole support")
        center=position[:]
        center[component]=literal(face) - 4
        radius=literal(p["diameter"])/2
        if (radius*SCALE).denominator != 1:
            raise ValueError("diameter is not exact on the 1/16 mm grid")
        bores.append({"id":"north" if axis=="x" else "east", "axis":axis,
                      "center_mm":[int(v*SCALE) for v in center],
                      "radius_mm":int(radius*SCALE)})
    if len({b["axis"] for b in bores}) != 2:
        raise ValueError("source holes must use the two distinct transverse axes")
    sketch_recipe={"family":"orthogonal_sketch_features_v1",
       "outer":{"id":"profile", "vertices":vertices}, "height_mm":height,
       "fillets":[{"id":"inside_round", "vertex":[128,128],
                    "radius_mm":int(fillet_radius*SCALE)}], "bores":bores}
    return {"family":"affine_image_v1", "source":sketch_recipe,
       "transform":{"matrix":[[1,0,0],[0,1,0],[0,0,1]],
                     "translation":[0,0,0], "denominator":SCALE}}

def call(cli, *args):
    p=subprocess.run([str(cli), *map(str,args)], capture_output=True, text=True)
    try: result=json.loads(p.stdout)
    except json.JSONDecodeError: raise RuntimeError(p.stdout+p.stderr)
    if p.returncode: raise RuntimeError(json.dumps(result,sort_keys=True))
    return result

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--cli", type=Path, default=None)
    args=parser.parse_args()
    root=args.root.resolve(); out=root/"build/fieldcraft-replay"; inp=out/"inputs"
    cli=(args.cli or root/"target/release/solidcraft-trivariate").resolve()
    manifest=json.loads((out/"source_manifest.json").read_text())["cases"]
    rows=[]
    for case in CASES:
        source=inp/f"{case}.script.json"
        source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
        if source_sha != manifest[case]["sha256"]:
            raise RuntimeError(f"source intent hash mismatch: {case}")
        script=json.loads(source.read_text())
        recipe=recipe_from_script(script)
        rp=out/f"{case}.recipe.json"; rp.write_text(json.dumps(recipe,separators=(",",":"))+"\n")
        model=out/f"{case}.model.json"; report=call(cli,"build",rp,model)
        audit=call(cli,"audit",model)
        if audit.get("status") != "valid": raise RuntimeError(f"{case} audit is not valid: {audit}")
        step=out/f"{case}.step"; call(cli,"export-step",model,step)
        audit_path=out/f"{case}.audit.json"; audit_path.write_text(json.dumps(audit,indent=2)+"\n")
        radii=[Fraction(b["radius_mm"], SCALE) for b in recipe["source"]["bores"]]
        pi_coefficient=360+8*sum((r*r for r in radii), Fraction(0))
        rows.append({"case":case,"input":str(source.relative_to(root)),
                     "input_sha256":source_sha,
                     "recipe":str(rp.relative_to(root)),"model":str(model.relative_to(root)),
                     "step":str(step.relative_to(root)),"audit":audit,
                     "analytic_volume_mm3":f"34080 - {pi_coefficient}*pi"})
    (out/"summary.json").write_text(json.dumps(rows,indent=2)+"\n")
    print(json.dumps(rows,indent=2))

if __name__ == "__main__": main()

# Source for the original FieldCraft job

Repository: `tangency-labs/fieldcraft`, pinned revision `35e834652d8548384c2da8ef1b28d588c9af2ffd` (also listed in `references.lock`). The original recipe and files are not duplicated in this archive. At that revision they are under `tests/oracle/filleted-bracket-fillet-stress/{recipe.json,design.json,fixture.json,expected.json,README.md}`. The generic geometry is also in `tests/corpus/filleted-bracket/`. The `bracket-hex` sample is defined in `crates/engine/src/sample.rs`.

In the stress recipe, `F2:side:l1` is fixed and `F2:side:l5` receives a 2,000 N force in +x; isotropic material has E=210000 MPa and nu=0.3. These references were used to adapt a uniform-traction job to the native model.

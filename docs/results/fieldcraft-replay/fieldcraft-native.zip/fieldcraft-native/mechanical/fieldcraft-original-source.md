# Référence du job FieldCraft original

Dépôt `tangency-labs/fieldcraft`, révision verrouillée `35e834652d8548384c2da8ef1b28d588c9af2ffd` (entrée correspondante dans `references.lock`). La recette et les fichiers originaux ne sont pas dupliqués dans cette archive; ils sont accessibles dans cette révision sous `tests/oracle/filleted-bracket-fillet-stress/{recipe.json,design.json,fixture.json,expected.json,README.md}`. La géométrie générique est aussi dans `tests/corpus/filleted-bracket/`. Le sample `bracket-hex` est défini dans `crates/engine/src/sample.rs`.

Dans la recette de stress, `F2:side:l1` est l'ensemble encastré, `F2:side:l5` reçoit une force de 2000 N en +x; matériau isotrope E=210000 MPa, nu=0.3. Ces références ont servi à adapter un job de traction uniforme sur le modèle natif.

# Native FieldCraft — five bracket variants

This archive contains five variants of the same L-shaped support, with recipes, models, AP214 STEP files, and audits. It also includes the FieldCraft `bracket-hex` mechanical job run on the PA5 model. `replay/` contains the five source SolidCraft scripts, their SHA-256 values, a deterministic converter, and a summary. `source-patch/` contains the minimal shared-guard change and its test.

## Geometry and audits

The profile is the L `[0,0]-[60,0]-[60,8]-[8,8]-[8,50]-[0,50]`, extruded 40 mm with an inside R6 fillet. Case names preserve campaign identifiers; bore radii are stated in the recipes:

| Case | X-axis bore radius (mm) | Y-axis bore radius (mm) | Exact volume |
|---|---:|---:|---|
| `x40-y80` | 5.000 | 2.500 | 34080 − 610π mm³ |
| `x50-y74` | 4.625 | 3.125 | 34080 − 2437π/4 mm³ |
| `x51-y74` | 4.625 | 3.1875 | 34080 − 19597π/32 mm³ |
| `x64-y64` | 4.000 | 4.000 | 34080 − 616π mm³ |
| `x80-y40` | 2.500 | 5.000 | 34080 − 610π mm³ |

Each certified affine model has 48 blocks, 74 shared interfaces, 140 exterior faces, and two through bores. Its audit includes a strictly positive determinant lower bound; the stated Hausdorff bound for the rational image is 0 mm. Details are in `variants/<case>/<case>.audit.json`; the summary is `reports/geometry-audit/summary.json`.

The OCC/FreeCAD check compares each exported STEP independently with its SolidCraft reference STEP, using adaptive volume integration, interior classification, and radial probes. All five reports under `reports/step-oracle/` have `qualification_pass`. These results characterize the audited artifacts; they do not prove general parametric identity beyond the recorded measurements.

## Replaying construction

Extract the archive into a compatible clone, then copy `build/fieldcraft-native/replay/` to `build/fieldcraft-replay/`. Apply `source-patch/orthogonal-sketch-shared-guard.patch` if the target revision does not already include the change. The patch touches only `src/orthogonal_sketch.rs` and `tests/solidcraft_sketch_features.rs`; its isolated base is `88e5f34ad13210db01256a5fe54f85001d2edc3d`.

From the repository root:

```sh
cargo build --release --bin solidcraft-trivariate
python3 build/fieldcraft-replay/replay.py --root . --cli target/release/solidcraft-trivariate
```

The script verifies SHA-256 values for the five SolidCraft intents, converts them on the exact 1/16 mm grid, then builds, audits, and exports the five models. Outputs go under `build/fieldcraft-replay/`. `source_manifest.json` records script hashes and origins. Make/Clippy logs from the generation clone are under `reports/geometry-audit/`.

## Mechanical job

`mechanical/fieldcraft_bracket_hex_pa5.job.json` adapts the original FieldCraft job; revision and paths are recorded in `mechanical/fieldcraft-original-source.md`. Historical faces `F2:side:l1` and `F2:side:l5` correspond to y=0 and y=50: the foot is fixed, and the upright receives +x traction of 6.25 MPa over 320 mm², giving 2 kN. The exact model is `mechanical/bracket-sketch.model.json`, using the 48-block PA5 partition; its STEP was exported directly from this model. The result and report are alongside it.

The native solver uses a continuous Q2 space (705 scalar DOFs); reaction and equilibrium were checked and compared with an independent SciPy assembly/solve. This job does not reproduce FieldCraft's tet10 mesh, solver, or fillet stress peak. The source recipe specifies a total force; the native job represents it by a uniform traction with equivalent resultant and moment.

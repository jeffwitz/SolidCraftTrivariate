# Job FieldCraft `bracket-hex` appliqué au modèle PA5

## Source et choix des faces

Le job source est `filleted-bracket-fillet-stress` de FieldCraft, révision `35e834652d8548384c2da8ef1b28d588c9af2ffd`; les chemins amont sont consignés dans `fieldcraft-original-source.md`. Il encastre `F2:side:l1` et applique une force de 2000 N en +x sur `F2:side:l5`. Le profil SolidCraft ordonné `(0,0) -> (60,0) -> (60,8) -> (8,8) -> (8,50) -> (0,50)`, extrudé suivant +z sur 40 mm, identifie ces faces comme les plans y=0 (pied horizontal) et y=50 (extrémité supérieure du montant). La sélection mécanique emploie ces plans et la provenance `outer/outline`.

L’API native accepte une traction surfacique plutôt qu’une force totale; l’équivalent réparti est 6.25 MPa en +x sur y=50. L’aire est 8×40=320 mm², soit 2000 N. Acier E=210000 MPa, nu=0.3; intégration q8. Toutes les composantes de déplacement sont fixées sur y=0. L’entrée est `fieldcraft_bracket_hex_pa5.job.json`; le modèle exact calculé est `bracket-sketch.model.json` et son STEP a été exporté depuis ce même modèle (ce n’est pas `probe.step`).

## Résultat

Commande depuis le clone: `cargo run --quiet -- solve-job build/fieldcraft-replay/bracket-sketch.json build/fieldcraft-native/mechanical/fieldcraft_bracket_hex_pa5.job.json build/fieldcraft-native/mechanical/bracket-sketch.result.json`.

Le modèle contient 48 blocs; espace Q2: 705 degrés de liberté scalaires, soit 2115 coefficients vectoriels; après contraintes, le système réduit compte 1749 inconnues. Le montage a le rang rigide 6. Le solveur converge en 298 itérations avec résidu relatif 9.79e-11. Quatre faces de charge totalisent 320.00000000000034 mm²; résultante [2000,0,0] N et moment autour de l’origine [0,40000,-100000] N·mm. Réaction calculée [-2000.00000002177,-2.98e-9,9.92e-11] N; déséquilibre relatif force 1.10e-11, moment 5.81e-12. Énergie de déformation 144.1284781 N·mm; erreur relative travail-énergie 3.25e-14.

Une résolution SciPy indépendante réassemble les blocs Q2 sérialisés et réintègre la traction: écart maximal du second membre 1.42e-13 N, écart relatif des coefficients de déplacement 5.32e-13. Ce résultat qualifie le transfert du job et l’équilibre sur PA5. Il ne reproduit pas le maillage tet10 ni le pic de contrainte au congé de FieldCraft.
